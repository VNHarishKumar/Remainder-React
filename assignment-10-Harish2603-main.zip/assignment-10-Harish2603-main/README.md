[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-8d59dc4de5201274e310e4c54b9627a8934c3b88527886e3b421487c677d23eb.svg)](https://classroom.github.com/a/QIcAv7Ya)

# Assignment - 10 Remainder app using react

# Description

- User should be able to view the remainders
- User should able to add new remainder
- User should delete the remainder
- User can mark the remainder as Complete

# Steps to Run

- The saved remaninders will be fetched on opening
- The user can add remainders by clicking add button and giving the necessary fields
- On clicking the check box the detailed desription of remainder can be viewed 
- On clicking the check box the remainder can be mark as complete 
- On clicking the delete button the remainder will be deleted from the UI and Data base

Name: Harish Kumar Vaithyan Nandhagopu
NUID: 002766063
